var searchData=
[
  ['buscarlivro',['buscarlivro',['../class_cntr_i_u_estante.html#a0ada4c7c0131f888081aa446bbd92f64',1,'CntrIUEstante::buscarlivro()'],['../class_i_u_estante.html#a0999af8632d4dae7524396d5b3f8788b',1,'IUEstante::buscarlivro()'],['../class_i_l_n_estante.html#ab0b211a49b8b652bbd69b99c6e6865b7',1,'ILNEstante::buscarlivro()'],['../class_stub_l_n_estante.html#ab5b3153cf5d1b7ae36d6cb5247c81e47',1,'StubLNEstante::buscarlivro()']]]
];
