var searchData=
[
  ['pesquisar_5flivro',['PESQUISAR_LIVRO',['../main_8cpp.html#a0a21dcfe93b16e2775293c040b2cadcf',1,'main.cpp']]],
  ['pesquisar_5fusuario',['PESQUISAR_USUARIO',['../main_8cpp.html#a0e30dd7191df1cccd9cf48ca522f2c29',1,'main.cpp']]]
];
