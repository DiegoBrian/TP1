var searchData=
[
  ['falha',['FALHA',['../class_resultado.html#a9a1c136d1a2189c25e6eaff45182083b',1,'Resultado']]]
];
