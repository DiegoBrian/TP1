var searchData=
[
  ['remover_5flivro',['REMOVER_LIVRO',['../main_8cpp.html#ac9401bb686771cb97330f3532eac4be2',1,'main.cpp']]]
];
