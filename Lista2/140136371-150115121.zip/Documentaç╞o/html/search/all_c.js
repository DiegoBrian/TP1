var searchData=
[
  ['remover_5flivro',['REMOVER_LIVRO',['../main_8cpp.html#ac9401bb686771cb97330f3532eac4be2',1,'main.cpp']]],
  ['resenha',['Resenha',['../class_resenha.html',1,'']]],
  ['resultado',['Resultado',['../class_resultado.html',1,'']]],
  ['resultadoautenticacao',['ResultadoAutenticacao',['../class_resultado_autenticacao.html',1,'']]],
  ['resultadobuscalivro',['ResultadoBuscaLivro',['../class_resultado_busca_livro.html',1,'']]],
  ['resultadoinsercao',['ResultadoInsercao',['../class_resultado_insercao.html',1,'']]]
];
