var searchData=
[
  ['autenticacao',['AUTENTICACAO',['../main_8cpp.html#a668b17f74a04b9c17968a76ef3550b8f',1,'main.cpp']]]
];
