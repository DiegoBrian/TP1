var searchData=
[
  ['telefone',['Telefone',['../class_telefone.html',1,'']]],
  ['texto',['Texto',['../class_texto.html',1,'']]],
  ['titulo',['Titulo',['../class_titulo.html',1,'']]]
];
