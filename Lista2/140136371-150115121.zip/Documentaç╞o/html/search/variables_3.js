var searchData=
[
  ['senha_5finvalida',['SENHA_INVALIDA',['../class_senha.html#a6882eae8d1991cef1bf1d256af6afccc',1,'Senha']]],
  ['sucesso',['SUCESSO',['../class_resultado.html#a234e15461a4fcccbbb82852278cd092f',1,'Resultado']]]
];
