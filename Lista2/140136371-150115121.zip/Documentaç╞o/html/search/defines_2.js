var searchData=
[
  ['incluir_5flivro',['INCLUIR_LIVRO',['../main_8cpp.html#ae42a5c48097e00ed49235185f2beb602',1,'main.cpp']]],
  ['informar_5ftroca',['INFORMAR_TROCA',['../main_8cpp.html#a193e6f1b0e9ddf36f9d92434e5b9165a',1,'main.cpp']]]
];
