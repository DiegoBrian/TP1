var searchData=
[
  ['livro',['Livro',['../class_livro.html',1,'']]],
  ['logoff',['LOGOFF',['../main_8cpp.html#a19e802e64ae728a2c54381328e70bcb4',1,'main.cpp']]]
];
