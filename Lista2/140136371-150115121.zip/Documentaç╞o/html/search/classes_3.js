var searchData=
[
  ['generoliterario',['GeneroLiterario',['../class_genero_literario.html',1,'']]]
];
