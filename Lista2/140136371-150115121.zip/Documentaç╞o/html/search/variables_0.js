var searchData=
[
  ['apelido_5finvalido',['APELIDO_INVALIDO',['../class_apelido.html#a4ae7b6274f323470d1d3dc2e11f762d0',1,'Apelido']]]
];
