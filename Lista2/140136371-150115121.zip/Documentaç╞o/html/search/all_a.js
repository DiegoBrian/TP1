var searchData=
[
  ['nome',['Nome',['../class_nome.html',1,'']]],
  ['nome_5finvalido',['NOME_INVALIDO',['../class_nome.html#ace6cbb4a02bd6f98c31eeddf936b904e',1,'Nome']]]
];
