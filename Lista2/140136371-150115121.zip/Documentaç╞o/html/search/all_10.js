var searchData=
[
  ['valor',['valor',['../class_resultado.html#a452e65ac80b05f5081642c869d960ac9',1,'Resultado']]]
];
